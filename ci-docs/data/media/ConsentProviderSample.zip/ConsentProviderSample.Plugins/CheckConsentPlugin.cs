﻿namespace Contoso.ConsentProviderSample.Plugins;

using System;
using Microsoft.Xrm.Sdk;

public sealed class CheckConsentPlugin : IPlugin
{
    public void Execute(IServiceProvider serviceProvider)
    {
        var pluginExecutionContext = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
        var strategy = new CheckConsentStrategy(pluginExecutionContext);
        strategy.Run();
    }
}
