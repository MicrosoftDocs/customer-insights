﻿namespace Contoso.ConsentProviderSample.Plugins;

using System.Runtime.Serialization;

[DataContract]
public class SampleContactPoint
{
    [DataMember(Name = "consentForMessage")]
    public bool ConsentForMessage { get; set; }

    [DataMember(Name = "email")]
    public string Email { get; set; }

    [DataMember(Name = "unsubscribeUrl")]
    public string UnsubscribeUrl { get; set; }

    [DataMember(Name = "oneClickUnsubscribeUrl")]
    public string OneClickUnsubscribeUrl { get; set; }
}