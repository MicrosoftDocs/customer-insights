﻿namespace Contoso.ConsentProviderSample.Plugins;

using System.Linq;
using System.Net;
using Microsoft.Xrm.Sdk;

public sealed class CheckConsentStrategy
{
    private readonly IPluginExecutionContext pluginExecutionContext;

    public CheckConsentStrategy(IPluginExecutionContext pluginExecutionContext)
    {
        this.pluginExecutionContext = pluginExecutionContext;
    }

    public void Run()
    {
        var complianceSettingsId = (EntityReference)this.pluginExecutionContext.InputParameters["complianceprofile"];
        if (complianceSettingsId == null)
        {
            throw new InvalidPluginExecutionException("complianceprofile parameter is not set");
        }

        var contactPoints = (string[])this.pluginExecutionContext.InputParameters["contactpoints"];
        if (contactPoints == null || contactPoints.Length == 0)
        {
            throw new InvalidPluginExecutionException("contactpoints parameter is not set");
        }

        var purposeId = (EntityReference)this.pluginExecutionContext.InputParameters["purpose"];
        if (purposeId == null)
        {
            throw new InvalidPluginExecutionException("purpose parameter is not set");
        }

        bool unsubscribeUrlRequired = false;
        if (this.pluginExecutionContext.InputParameters.TryGetValue("unsubscribeurlrequired", out var unsubscribeUrlRequiredValue) && unsubscribeUrlRequiredValue != null)
        {
            unsubscribeUrlRequired = (bool)unsubscribeUrlRequiredValue;
        }

        bool oneClickUnsubscribeUrlRequired = false;
        if (this.pluginExecutionContext.InputParameters.TryGetValue("oneclickunsubscribeurlrequired", out var oneClickUnsubscribeUrlRequiredValue) && oneClickUnsubscribeUrlRequiredValue != null)
        {
            oneClickUnsubscribeUrlRequired = (bool)oneClickUnsubscribeUrlRequiredValue;
        }

        Entity correlationHeaders = null;
        if (this.pluginExecutionContext.InputParameters.TryGetValue("correlationheaders", out var correlationHeadersRaw) && correlationHeadersRaw != null)
        {
            correlationHeaders = (Entity)correlationHeadersRaw;
        }

        var headers = new WebHeaderCollection();

        if (correlationHeaders != null)
        {
            foreach (var attribute in correlationHeaders.Attributes)
            {
                var attributeValue = attribute.Value as string;
                if (attributeValue != null)
                {
                    headers.Add(attribute.Key, attributeValue);
                }
            }
        }

        // here you would like to do a http call to your backend instead :) hardocding just for ilustration purpose
        var responses = new SampleContactPoint[contactPoints.Length];
        responses[0] = new SampleContactPoint
        {
            ConsentForMessage = true,
            Email = contactPoints[0],
            UnsubscribeUrl = "https://contoso.com/unsubscribe",
            OneClickUnsubscribeUrl = "https://contoso.com/unsubscribe-via-one-click",
        };

        this.pluginExecutionContext.OutputParameters["consents"] = new EntityCollection(responses.Select(r =>
            new Entity
            {
                ["consentformessage"] = r.ConsentForMessage,
                ["contactpoint"] = r.Email,
                ["unsubscribeurl"] = r.UnsubscribeUrl,
                ["oneclickunsubscribeurl"] = r.OneClickUnsubscribeUrl,
            }
        ).ToList());
    }
}
